```python
#First data analysis using jupitar notebook
#Covid 19 data analysis
```


```python
import pandas as pd

```


```python
print(' Covid 19 data analysis')
```

     Covid 19 data analysis
    


```python
import numpy as np
```


```python
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
import pandas as pd
# Load the dataset
data = pd.read_csv("covid.csv")

# Display the first few rows
print(data.head(2))

```

       UID iso2 iso3  code3  FIPS Admin2 Province_State Country_Region       Lat  \
    0    4   AF  AFG    4.0   NaN    NaN            NaN    Afghanistan  33.93911   
    1    8   AL  ALB    8.0   NaN    NaN            NaN        Albania  41.15330   
    
           Long_ Combined_Key  Population  
    0  67.709953  Afghanistan  38928341.0  
    1  20.168300      Albania   2877800.0  
    


```python
import pandas as pd
```


```python
data = pd.read_csv('covid.csv')
print(data.head())
```

       UID iso2 iso3  code3  FIPS Admin2 Province_State Country_Region       Lat  \
    0    4   AF  AFG    4.0   NaN    NaN            NaN    Afghanistan  33.93911   
    1    8   AL  ALB    8.0   NaN    NaN            NaN        Albania  41.15330   
    2   10   AQ  ATA   10.0   NaN    NaN            NaN     Antarctica -71.94990   
    3   12   DZ  DZA   12.0   NaN    NaN            NaN        Algeria  28.03390   
    4   20   AD  AND   20.0   NaN    NaN            NaN        Andorra  42.50630   
    
           Long_ Combined_Key  Population  
    0  67.709953  Afghanistan  38928341.0  
    1  20.168300      Albania   2877800.0  
    2  23.347000   Antarctica         NaN  
    3   1.659600      Algeria  43851043.0  
    4   1.521800      Andorra     77265.0  
    

THis is the firsst learning process for data science



```python
print(data.shape)  # Rows and columns

```

    (4321, 12)
    


```python
print(data.isnull().sum())
#THis code for the missing value
```

    UID                 0
    iso2                5
    iso3                4
    code3               4
    FIPS              937
    Admin2            978
    Province_State    202
    Country_Region      0
    Lat               148
    Long_             148
    Combined_Key        0
    Population        151
    dtype: int64
    


```python
print(data.describe())

```

                    UID        code3          FIPS          Lat        Long_  \
    count  4.321000e+03  4317.000000   3384.000000  4173.000000  4173.000000   
    mean   6.574015e+07   754.532546  32535.782506    35.828520   -67.948965   
    std    3.431740e+07   189.159831  18945.380455    13.631526    57.106672   
    min    4.000000e+00     4.000000      1.000000   -71.949900  -178.116500   
    25%    8.400106e+07   840.000000  18182.500000    33.214988   -96.401346   
    50%    8.402123e+07   840.000000  30072.000000    38.081636   -86.045250   
    75%    8.404011e+07   840.000000  47103.500000    42.595140   -75.751186   
    max    8.410000e+07   894.000000  99999.000000    71.706900   178.065000   
    
             Population  
    count  4.170000e+03  
    mean   3.074123e+06  
    std    3.349758e+07  
    min    6.700000e+01  
    25%    1.451350e+04  
    50%    4.111650e+04  
    75%    2.809602e+05  
    max    1.411779e+09  
    


```python
print(data.info())

```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4321 entries, 0 to 4320
    Data columns (total 12 columns):
     #   Column          Non-Null Count  Dtype  
    ---  ------          --------------  -----  
     0   UID             4321 non-null   int64  
     1   iso2            4316 non-null   object 
     2   iso3            4317 non-null   object 
     3   code3           4317 non-null   float64
     4   FIPS            3384 non-null   float64
     5   Admin2          3343 non-null   object 
     6   Province_State  4119 non-null   object 
     7   Country_Region  4321 non-null   object 
     8   Lat             4173 non-null   float64
     9   Long_           4173 non-null   float64
     10  Combined_Key    4321 non-null   object 
     11  Population      4170 non-null   float64
    dtypes: float64(5), int64(1), object(6)
    memory usage: 405.2+ KB
    None
    


```python

```

TO clean the data 


```python
# Drop rows with missing values
data_cleaned = data.dropna()



```


```python
data['UID'] = data['UID'].fillna("Unknown").mean()  # Replace "Unknown" with any desired default value

```


```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4321 entries, 0 to 4320
    Data columns (total 12 columns):
     #   Column          Non-Null Count  Dtype  
    ---  ------          --------------  -----  
     0   UID             4321 non-null   int64  
     1   iso2            4316 non-null   object 
     2   iso3            4317 non-null   object 
     3   code3           4317 non-null   float64
     4   FIPS            3384 non-null   float64
     5   Admin2          4321 non-null   object 
     6   Province_State  4119 non-null   object 
     7   Country_Region  4321 non-null   object 
     8   Lat             4173 non-null   float64
     9   Long_           4173 non-null   float64
     10  Combined_Key    4321 non-null   object 
     11  Population      4170 non-null   float64
    dtypes: float64(5), int64(1), object(6)
    memory usage: 405.2+ KB
    


```python
if "Admin" in data.columns and pd.api.types.is_numeric_dtype(data["Admin"]):
    data['Admin2'] = data['Admin2'].fillna(data['Admin'].mean())
else:
    print("The column 'Admin' either doesn't exist or isn't numeric.")

```

    The column 'Admin' either doesn't exist or isn't numeric.
    


```python
data.rename(columns={"Admin2": "NewName"}, inplace=True)

```


```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4321 entries, 0 to 4320
    Data columns (total 12 columns):
     #   Column          Non-Null Count  Dtype  
    ---  ------          --------------  -----  
     0   UID             4321 non-null   float64
     1   iso2            4316 non-null   object 
     2   iso3            4317 non-null   object 
     3   code3           4317 non-null   float64
     4   FIPS            3384 non-null   float64
     5   NewName         4321 non-null   object 
     6   Province_State  4119 non-null   object 
     7   Country_Region  4321 non-null   object 
     8   Lat             4173 non-null   float64
     9   Long_           4173 non-null   float64
     10  Combined_Key    4321 non-null   object 
     11  Population      4170 non-null   float64
    dtypes: float64(6), object(6)
    memory usage: 405.2+ KB
    


```python
#to change the name of row or column 
data.rename(columns={"NewName": "Admin2"}, inplace=True )
```


```python
#to check change in column i run the command as 
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4321 entries, 0 to 4320
    Data columns (total 12 columns):
     #   Column          Non-Null Count  Dtype  
    ---  ------          --------------  -----  
     0   UID             4321 non-null   float64
     1   iso2            4316 non-null   object 
     2   iso3            4317 non-null   object 
     3   code3           4317 non-null   float64
     4   FIPS            3384 non-null   float64
     5   Admin2          4321 non-null   object 
     6   Province_State  4119 non-null   object 
     7   Country_Region  4321 non-null   object 
     8   Lat             4173 non-null   float64
     9   Long_           4173 non-null   float64
     10  Combined_Key    4321 non-null   object 
     11  Population      4170 non-null   float64
    dtypes: float64(6), object(6)
    memory usage: 405.2+ KB
    


```python
#in column 5 it shows Admin2 as renamed name
```

CHAPTER 2 DATA ANALYSIS



```python
#TO SHOW MOST COUNTRY AFFECTED BY COVID 
```


```python
cases_by_country = data.groupby("Country_Region")["Population"].sum()
print(cases_by_country)

```

    Country_Region
    Afghanistan             38928341.0
    Albania                  2877800.0
    Algeria                 43851043.0
    Andorra                    77265.0
    Angola                  32866268.0
                               ...    
    Western Sahara            597330.0
    Winter Olympics 2022           0.0
    Yemen                   29825968.0
    Zambia                  18383956.0
    Zimbabwe                14862927.0
    Name: Population, Length: 202, dtype: float64
    


```python
data.head(12)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>UID</th>
      <th>iso2</th>
      <th>iso3</th>
      <th>code3</th>
      <th>FIPS</th>
      <th>Admin2</th>
      <th>Province_State</th>
      <th>Country_Region</th>
      <th>Lat</th>
      <th>Long_</th>
      <th>Combined_Key</th>
      <th>Population</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6.574015e+07</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4.0</td>
      <td>NaN</td>
      <td>Unknown</td>
      <td>NaN</td>
      <td>Afghanistan</td>
      <td>33.939110</td>
      <td>67.709953</td>
      <td>Afghanistan</td>
      <td>38928341.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6.574015e+07</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8.0</td>
      <td>NaN</td>
      <td>Unknown</td>
      <td>NaN</td>
      <td>Albania</td>
      <td>41.153300</td>
      <td>20.168300</td>
      <td>Albania</td>
      <td>2877800.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>6.574015e+07</td>
      <td>AQ</td>
      <td>ATA</td>
      <td>10.0</td>
      <td>NaN</td>
      <td>Unknown</td>
      <td>NaN</td>
      <td>Antarctica</td>
      <td>-71.949900</td>
      <td>23.347000</td>
      <td>Antarctica</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>6.574015e+07</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12.0</td>
      <td>NaN</td>
      <td>Unknown</td>
      <td>NaN</td>
      <td>Algeria</td>
      <td>28.033900</td>
      <td>1.659600</td>
      <td>Algeria</td>
      <td>43851043.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6.574015e+07</td>
      <td>AD</td>
      <td>AND</td>
      <td>20.0</td>
      <td>NaN</td>
      <td>Unknown</td>
      <td>NaN</td>
      <td>Andorra</td>
      <td>42.506300</td>
      <td>1.521800</td>
      <td>Andorra</td>
      <td>77265.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6.574015e+07</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24.0</td>
      <td>NaN</td>
      <td>Unknown</td>
      <td>NaN</td>
      <td>Angola</td>
      <td>-11.202700</td>
      <td>17.873900</td>
      <td>Angola</td>
      <td>32866268.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6.574015e+07</td>
      <td>AG</td>
      <td>ATG</td>
      <td>28.0</td>
      <td>NaN</td>
      <td>Unknown</td>
      <td>NaN</td>
      <td>Antigua and Barbuda</td>
      <td>17.060800</td>
      <td>-61.796400</td>
      <td>Antigua and Barbuda</td>
      <td>97928.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>6.574015e+07</td>
      <td>AR</td>
      <td>ARG</td>
      <td>32.0</td>
      <td>NaN</td>
      <td>Unknown</td>
      <td>NaN</td>
      <td>Argentina</td>
      <td>-38.416100</td>
      <td>-63.616700</td>
      <td>Argentina</td>
      <td>45195777.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>6.574015e+07</td>
      <td>AM</td>
      <td>ARM</td>
      <td>51.0</td>
      <td>NaN</td>
      <td>Unknown</td>
      <td>NaN</td>
      <td>Armenia</td>
      <td>40.069100</td>
      <td>45.038200</td>
      <td>Armenia</td>
      <td>2963234.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>6.574015e+07</td>
      <td>AT</td>
      <td>AUT</td>
      <td>40.0</td>
      <td>NaN</td>
      <td>Unknown</td>
      <td>NaN</td>
      <td>Austria</td>
      <td>47.516200</td>
      <td>14.550100</td>
      <td>Austria</td>
      <td>9006400.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>6.574015e+07</td>
      <td>AZ</td>
      <td>AZE</td>
      <td>31.0</td>
      <td>NaN</td>
      <td>Unknown</td>
      <td>NaN</td>
      <td>Azerbaijan</td>
      <td>40.143100</td>
      <td>47.576900</td>
      <td>Azerbaijan</td>
      <td>10139175.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>6.574015e+07</td>
      <td>BS</td>
      <td>BHS</td>
      <td>44.0</td>
      <td>NaN</td>
      <td>Unknown</td>
      <td>NaN</td>
      <td>Bahamas</td>
      <td>25.025885</td>
      <td>-78.035889</td>
      <td>Bahamas</td>
      <td>393248.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
case = data.groupby("Admin2")["Country_Region"].sum()
print(case)
```

    Admin2
    Abbeville              US
    Acadia                 US
    Accomack               US
    Ada                    US
    Adair            USUSUSUS
                       ...   
    Yukon-Koyukuk          US
    Yuma                 USUS
    Zapata                 US
    Zavala                 US
    Ziebach                US
    Name: Country_Region, Length: 1987, dtype: object
    

CHAPTER 3  VISUALIZE THESE DATA 



```python
import matplotlib.pyplot as plt
import seaborn as sns

# Bar plot of top 20 countries with most cases
top_countries = cases_by_country.sort_values(ascending=False).head(5)
top_countries.plot(kind="bar", title="Top 20 Countries with Most Cases")
plt.show()

```


    
![png](output_30_0.png)
    



```python
import matplotlib.pyplot as plt
```


```python
import seaborn as sns
```


```python
# to show least countries affected by covid
least_countries= cases_by_country.sort_values(ascending=True).head(20)
least_countries.plot(kind="pie", title="Top 20 Countries with least Cases")
plt.show()

```


    
![png](output_33_0.png)
    



```python
# to show least countries affected by covid
least_countries= cases_by_country.sort_values(ascending=True).head(20)
least_countries.plot(kind="bar", title="Top 20 Countries with least Cases")
plt.show()
```


    
![png](output_34_0.png)
    



```python
# to show least countries affected by covid
least_countries= cases_by_country.sort_values(ascending=True).head(20)
least_countries.plot(kind="bar", title="Top 20 Countries with least Cases")
plt.show()
```


    
![png](output_35_0.png)
    



```python
styles = ['default', 'ggplot']
colors = ['skyblue', 'salmon']

for style in styles:
    for color in colors:
        plt.style.use(style)
        least_countries.plot(kind="bar", color=color, title=f"Bar Chart ({style}, {color})")
        plt.ylabel("Cases")
        plt.xlabel("Countries")
        plt.tight_layout()
        plt.savefig("filename")
        plt.show()

```


    
![png](output_36_0.png)
    



    
![png](output_36_1.png)
    



    
![png](output_36_2.png)
    



    
![png](output_36_3.png)
    



```python
import matplotlib.pyplot as plt

# Original plot: Vertical bar chart
least_countries.plot(kind="bar", color="skyblue", title="Top 20 Countries with Least Cases")
plt.ylabel("Cases")
plt.xlabel("Countries")
plt.tight_layout()
plt.savefig("vertical_bar_chart.png")  # Save the plot
plt.show()

# Variation 1: Horizontal bar chart
least_countries.plot(kind="barh", color="lightgreen", title="Top 20 Countries with Least Cases")
plt.ylabel("Countries")
plt.xlabel("Cases")
plt.tight_layout()
plt.savefig("horizontal_bar_chart.png")
plt.show()

# Variation 2: Bar chart with data labels
ax = least_countries.plot(kind="bar", color="salmon", title="Top 20 Countries with Least Cases with Data Labels")
for i, v in enumerate(least_countries):
    ax.text(i, v + 500, str(v), ha="center", va="bottom")  # Adjust text positioning
plt.ylabel("Cases")
plt.xlabel("Countries")
plt.tight_layout()
plt.savefig("bar_chart_with_labels.png")
plt.show()

# Variation 3: Different theme
plt.style.use("ggplot")  # Change style
least_countries.plot(kind="bar", color="darkorange", title="Styled Bar Chart (ggplot)")
plt.ylabel("Cases")
plt.xlabel("Countries")
plt.tight_layout()
plt.savefig("styled_bar_chart.png")
plt.show()

# Variation 4: Different figure size
plt.figure(figsize=(12, 6))  # Adjust figure size
least_countries.plot(kind="bar", color="purple", title="Wide Bar Chart")
plt.ylabel("Cases")
plt.xlabel("Countries")
plt.tight_layout()
plt.savefig("wide_bar_chart.png")
plt.show()

```


    
![png](output_37_0.png)
    



    
![png](output_37_1.png)
    



    
![png](output_37_2.png)
    



    
![png](output_37_3.png)
    



    
![png](output_37_4.png)
    



```python
# Variation 3: Different theme
plt.style.use("ggplot")  # Change style
least_countries.plot(kind="bar", color="darkorange", title="Styled Bar Chart (ggplot)")
plt.ylabel("Cases")
plt.xlabel("Countries")
plt.tight_layout()
plt.savefig("styled_bar_chart.png")
plt.show()
```


    
![png](output_38_0.png)
    



```python

```
